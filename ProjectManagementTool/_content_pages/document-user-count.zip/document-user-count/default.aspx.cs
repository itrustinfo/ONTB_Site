﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using ProjectManager.DAL;

namespace ProjectManagementTool._content_pages.document_user_count
{
    public partial class _default : System.Web.UI.Page
    {
        DBGetData getdt = new DBGetData();
        TaskUpdate gettk = new TaskUpdate();
        int totalcount = 0;
        int totalactcount = 0;
        int totalgdcount = 0;
        int totaldwnldcount = 0;
        int totalviewcount = 0;
        int grandtotalcount = 0;
        int grandtotaldwnldcount = 0;
        int grandtotalviewcount = 0;
        int GrandTotalDocumentLinkSent = 0;
        int TotalDocumentLinkSentCount = 0;
        string name = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] == null)
            {
                Response.Redirect("~/Login.aspx");
            }
            else
            {
                if (!IsPostBack)
                {
                    BindProject();
                    LoadUsers();
                }
            }
        }

        private void BindProject()
        {
            DataTable ds = new DataTable();
            if (Session["TypeOfUser"].ToString() == "U" || Session["TypeOfUser"].ToString() == "MD" || Session["TypeOfUser"].ToString() == "VP")
            {
                ds = gettk.GetProjects();
            }
            else if (Session["TypeOfUser"].ToString() == "PA")
            {
                ds = gettk.GetAssignedProjects_by_UserUID(new Guid(Session["UserUID"].ToString()));
            }
            else
            {
                ds = gettk.GetAssignedProjects_by_UserUID(new Guid(Session["UserUID"].ToString()));
            }

            ddlProject.DataTextField = "ProjectName";
            ddlProject.DataValueField = "ProjectUID";
            ddlProject.DataSource = ds;
            ddlProject.DataBind();
            ddlProject.Items.Add("General Documents");
           
            ddlProject.Items.Insert(0, "All Projects");
            ddlProject.Items.Insert(0, "Select Project");


        }

        private void LoadUsers()
        {
            try
            {
                ddlusers.Items.Clear();
                if (ddlProject.SelectedValue == "All Projects" || ddlProject.SelectedValue == "General Documents")
                {
                    ddlusers.DataSource = getdt.GetUserList();
                    ddlusers.DataTextField = "Name";
                    ddlusers.DataValueField = "UserUID";
                    ddlusers.DataBind();
                }
                else if (ddlProject.SelectedValue != "All Projects" && ddlProject.SelectedIndex != 0)
                {
                    ddlusers.DataSource = getdt.GetUserListByPrj(new Guid(ddlProject.SelectedValue));
                    ddlusers.DataTextField = "Name";
                    ddlusers.DataValueField = "UserUID";
                    ddlusers.DataBind();
                }
                ddlusers.Items.Insert(0, "All Users");
                ddlusers.Items.Insert(0, "Select User");

                if (ddlProject.SelectedValue == "General Documents")
                {
                    DDLStatus.SelectedValue = "Submitted";
                    DDLStatus.Enabled = false;
                }
                else
                {
                    DDLStatus.SelectedIndex = 0;
                    DDLStatus.Enabled = true;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    
        private void LoadProjects()
        {
            try
            {
                if (ddlusers.SelectedValue != "All Users")
                {
                    grdDocumenthistoryAll.Visible = false;
                    GrdDcumentHistory.Visible = true;
                    if (ddlProject.SelectedIndex != 0 && ddlProject.SelectedValue == "All Projects")
                    {
                        GrdDcumentHistory.DataSource = getdt.GetUserProjects(new Guid(ddlusers.SelectedValue), 1, Guid.NewGuid());
                        GrdDcumentHistory.DataBind();
                    }
                    else if (ddlProject.SelectedIndex != 0 && ddlProject.SelectedValue != "All Projects" && ddlProject.SelectedValue != "General Documents")
                    {
                        GrdDcumentHistory.DataSource = getdt.GetUserProjects(new Guid(ddlusers.SelectedValue), 2, new Guid(ddlProject.SelectedValue));
                        GrdDcumentHistory.DataBind();
                    }
                    else if (ddlProject.SelectedValue == "General Documents")
                    {
                        GrdDcumentHistory.DataSource = getdt.GetUserProjects(new Guid(ddlusers.SelectedValue), 3, Guid.NewGuid());
                        GrdDcumentHistory.DataBind();
                    }
                }
                else if (ddlusers.SelectedValue == "All Users")
                {
                    lblDocumentsNo.Text = "";
                    grdDocumenthistoryAll.Visible = true;
                    GrdDcumentHistory.Visible = false;

                    DataTable dt = new DataTable();
                    DataRow dr;


                    // Add Columns to datatablse
                    dt.Columns.Add(new DataColumn("ProjectName")); //'ColumnName1' represents name of datafield in grid
                    dt.Columns.Add(new DataColumn("ProjectName1"));
                    dt.Columns.Add(new DataColumn("ProjectUID1"));
                    dt.Columns.Add(new DataColumn("ProjectUID2"));
                    dt.Columns.Add(new DataColumn("ProjectUID3"));
                    dt.Columns.Add(new DataColumn("ProjectUID4"));
                    foreach (DataRow gvr in getdt.GetUserList().Tables[0].Rows)
                    {
                        if (ddlProject.SelectedValue != "All Projects" && ddlProject.SelectedValue != "General Documents")
                        {
                            foreach (DataRow gr in getdt.GetUserProjects(new Guid(gvr["UserUID"].ToString()), 5, new Guid(ddlProject.SelectedValue)).Tables[0].Rows)
                            {
                                dr = dt.NewRow();
                                dr["ProjectName"] = gvr["UserUID"].ToString();
                                dr["ProjectName1"] = gr["ProjectName"].ToString();
                                dr["ProjectUID1"] = gr["ProjectUID"].ToString();
                                dr["ProjectUID2"] = gr["ProjectUID"].ToString();
                                dr["ProjectUID3"] = gr["ProjectUID"].ToString();
                                dr["ProjectUID4"] = gr["ProjectUID"].ToString();
                                dt.Rows.Add(dr);
                            }
                        }
                        else if (ddlProject.SelectedValue == "General Documents")
                        {
                            foreach (DataRow gr in getdt.GetUserProjects(new Guid(gvr["UserUID"].ToString()), 3, Guid.NewGuid()).Tables[0].Rows)
                            {
                                dr = dt.NewRow();
                                dr["ProjectName"] = gvr["UserUID"].ToString();
                                dr["ProjectName1"] = gr["ProjectName"].ToString();
                                dr["ProjectUID1"] = gr["ProjectUID"].ToString();
                                dr["ProjectUID2"] = gr["ProjectUID"].ToString();
                                dr["ProjectUID3"] = gr["ProjectUID"].ToString();
                                dr["ProjectUID4"] = gr["ProjectUID"].ToString();
                                dt.Rows.Add(dr);
                            }
                        }
                        else
                        {
                            foreach (DataRow gr in getdt.GetUserProjects(new Guid(gvr["UserUID"].ToString()), 4, Guid.NewGuid()).Tables[0].Rows)
                            {
                                dr = dt.NewRow();
                                dr["ProjectName"] = gvr["UserUID"].ToString();
                                dr["ProjectName1"] = gr["ProjectName"].ToString();
                                dr["ProjectUID1"] = gr["ProjectUID"].ToString();
                                dr["ProjectUID2"] = gr["ProjectUID"].ToString();
                                dr["ProjectUID3"] = gr["ProjectUID"].ToString();
                                dr["ProjectUID4"] = gr["ProjectUID"].ToString();
                                dt.Rows.Add(dr);
                            }
                        }
                        dr = dt.NewRow();
                        dr["ProjectName"] = "";
                        dr["ProjectName1"] = "Total";
                        dr["ProjectUID1"] = "";
                        dr["ProjectUID2"] = "";
                        dr["ProjectUID3"] = "";
                        dr["ProjectUID4"] = "";
                        dt.Rows.Add(dr);


                    }
                    grdDocumenthistoryAll.DataSource = dt;
                    grdDocumenthistoryAll.DataBind();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void LoadDocuments()
        {
            try
            {
                DateTime FromDate = DateTime.Now;
                DateTime ToDate = DateTime.Now;
                if (!string.IsNullOrEmpty(dtFromDate.Text))
                {
                    FromDate = Convert.ToDateTime(getdt.ConvertDateFormat(dtFromDate.Text));
                }
                if (!string.IsNullOrEmpty(dtToDate.Text))
                {
                    ToDate = Convert.ToDateTime(getdt.ConvertDateFormat(dtToDate.Text));
                }
                if (ddlProject.SelectedValue == "All Projects" && ddlusers.SelectedValue != "All Users")
                {
                    if (dtFromDate.Text != "" && dtToDate.Text != "")
                    {
                        GrdDocuments.DataSource = getdt.GetAllUserDocuments(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 1, DDLStatus.SelectedValue, DDLFilter.SelectedValue);
                    }
                    else
                    {
                        GrdDocuments.DataSource = getdt.GetAllUserDocuments(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 0, DDLStatus.SelectedValue, DDLFilter.SelectedValue);

                    }
                }
                else if (ddlProject.SelectedValue != "All Projects" && ddlusers.SelectedValue == "All Users" && ddlProject.SelectedValue != "General Documents")
                {
                    if (dtFromDate.Text != "" && dtToDate.Text != "")
                    {
                        GrdDocuments.DataSource = getdt.GetProjectwiseDocuments_For_AllUsers(FromDate, ToDate, 1, new Guid(ddlProject.SelectedValue), DDLStatus.SelectedValue, DDLFilter.SelectedValue);
                    }
                    else
                    {
                        GrdDocuments.DataSource = getdt.GetProjectwiseDocuments_For_AllUsers(FromDate, ToDate, 0, new Guid(ddlProject.SelectedValue), DDLStatus.SelectedValue, DDLFilter.SelectedValue);
                    }
                }
                else if (ddlProject.SelectedValue != "All Projects" && ddlusers.SelectedValue != "All Users" && ddlProject.SelectedValue != "General Documents")
                {
                    if (dtFromDate.Text != "" && dtToDate.Text != "")
                    {
                        GrdDocuments.DataSource = getdt.GetAllUserDocumentsByPrj(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 1, new Guid(ddlProject.SelectedValue), DDLStatus.SelectedValue, DDLFilter.SelectedValue);

                    }
                    else
                    {
                        GrdDocuments.DataSource = getdt.GetAllUserDocumentsByPrj(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 0, new Guid(ddlProject.SelectedValue), DDLStatus.SelectedValue, DDLFilter.SelectedValue);

                    }
                }
                else if (ddlProject.SelectedValue == "All Projects" && ddlusers.SelectedValue == "All Users")
                {
                    if (dtFromDate.Text != "" && dtToDate.Text != "")
                    {
                        GrdDocuments.DataSource = getdt.GetAllProject_AllUser_Documents(FromDate, ToDate, 1, DDLStatus.SelectedValue, DDLFilter.SelectedValue);
                    }
                    else
                    {
                        GrdDocuments.DataSource = getdt.GetAllProject_AllUser_Documents(FromDate, ToDate, 0, DDLStatus.SelectedValue, DDLFilter.SelectedValue);
                    }
                }
                else if (ddlProject.SelectedValue == "General Documents" && ddlusers.SelectedValue != "All Users")
                {
                    if (dtFromDate.Text != "" && dtToDate.Text != "")
                    {
                        GrdDocuments.DataSource = getdt.GetGDByUser(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 1, DDLFilter.SelectedValue);

                    }
                    else
                    {
                        GrdDocuments.DataSource = getdt.GetGDByUser(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 0, DDLFilter.SelectedValue);

                    }
                }
                else
                {
                    if (dtFromDate.Text != "" && dtToDate.Text != "")
                    {

                        GrdDocuments.DataSource = getdt.GetAllGeneralDocuments(FromDate, ToDate, 1, DDLFilter.SelectedValue);
                    }
                    else
                    {
                        GrdDocuments.DataSource = getdt.GetAllGeneralDocuments(FromDate, ToDate, 0, DDLFilter.SelectedValue);
                    }
                }
                GrdDocuments.DataBind();

                lblDocumentsNo.Text = "Total No. Of Documents : " + GrdDocuments.Rows.Count;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if(ddlProject.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "Alert", "<script language='javascript'>alert('Please select project !');</script>");
                return;
            }
            if (ddlusers.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "Alert", "<script language='javascript'>alert('Please select user !');</script>");
                return;
            }
            if (ddlOptions.SelectedIndex == 0)
            {
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "Alert", "<script language='javascript'>alert('Please select type of report !');</script>");
                return;
            }

            if (!string.IsNullOrEmpty(dtFromDate.Text) && dtToDate.Text == "")
            {
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "Alert", "<script language='javascript'>alert('Please enter To Date !');</script>");
                return;
            }
            if (dtFromDate.Text =="" && dtToDate.Text != "")
            {
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "Alert", "<script language='javascript'>alert('Please enter From Date !');</script>");
                return;
            }
           
            lblDocumentsNo.Visible = true;
            LoadProjects();
            if (ddlOptions.SelectedIndex == 1)
            {
                divsummary.Visible = true;
                divDetails.Visible = false;
                
            }
            else if (ddlOptions.SelectedIndex == 2)
            {
                divsummary.Visible = false;
                divDetails.Visible = true;
                LoadDocuments();
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            dtFromDate.Text = "";
            dtToDate.Text = "";
            divsummary.Visible = false;
            divDetails.Visible = false;
            ddlOptions.SelectedIndex = 0;
            ddlProject.SelectedIndex = 0;
            ddlusers.SelectedIndex = 0;
            lblDocumentsNo.Text = "";
        }

        public string GetDocumentTypeIcon(string DocumentExtn)
        {
            return getdt.GetDocumentTypeMasterIcon_by_Extension(DocumentExtn);
        }

        public string GetDocumentName(string DocumentExtn)
        {
            string retval = getdt.GetDocumentMasterType_by_Extension(DocumentExtn);
            if (retval == null || retval == "")
            {
                return "N/A";
            }
            else
            {
                return retval;
            }
        }

        protected void GrdDcumentHistory_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DateTime FromDate = DateTime.Now;
            DateTime ToDate = DateTime.Now;
            if (!string.IsNullOrEmpty(dtFromDate.Text))
            {
                FromDate = Convert.ToDateTime(getdt.ConvertDateFormat(dtFromDate.Text));
            }
            if (!string.IsNullOrEmpty(dtToDate.Text))
            {
                ToDate = Convert.ToDateTime(getdt.ConvertDateFormat(dtToDate.Text));
            }

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Guid PrjUID = new Guid(e.Row.Cells[2].Text);
                e.Row.Cells[0].Text = ddlusers.SelectedItem.ToString();
                if (name != e.Row.Cells[0].Text)
                {
                    totalcount = 0;
                    totalviewcount = 0;
                    totaldwnldcount = 0;
                    TotalDocumentLinkSentCount = 0;
                    e.Row.Cells[0].Text = ddlusers.SelectedItem.ToString();
                    name = e.Row.Cells[0].Text;
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                }
                if (e.Row.Cells[1].Text != "Total")
                {
                    if (e.Row.Cells[1].Text == "General Documents")
                    {
                        if (dtFromDate.Text != "" && dtToDate.Text != "")
                        {
                            e.Row.Cells[2].Text = getdt.GetGDByUsercount(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 1,"All").ToString();
                            e.Row.Cells[3].Text = getdt.GetDocCountViewDownldGD(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 1, "Downloaded").ToString();
                            e.Row.Cells[4].Text = getdt.GetDocCountViewDownldGD(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 1, "Viewed").ToString();
                            e.Row.Cells[5].Text = getdt.GetUserDocLinkSentCount_GD(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 1).ToString();

                        }
                        else
                        {
                            e.Row.Cells[2].Text = getdt.GetGDByUsercount(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 0, "All").ToString();
                            e.Row.Cells[3].Text = getdt.GetDocCountViewDownldGD(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 0, "Downloaded").ToString();
                            e.Row.Cells[4].Text = getdt.GetDocCountViewDownldGD(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 0, "Viewed").ToString();
                            e.Row.Cells[5].Text = getdt.GetUserDocLinkSentCount_GD(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 0).ToString();
                        }
                        totalgdcount = int.Parse(e.Row.Cells[2].Text);
                    }
                    else
                    {

                        if (dtFromDate.Text != "" && dtToDate.Text != "")
                        {
                            e.Row.Cells[2].Text = getdt.GetProjectdocumnetscountByPrj(new Guid(ddlusers.SelectedValue), PrjUID, FromDate, ToDate, 1).ToString();
                            e.Row.Cells[3].Text = getdt.GetDocCountViewDownld(new Guid(ddlusers.SelectedValue), PrjUID, FromDate, ToDate, 1, "Downloaded").ToString();
                            e.Row.Cells[4].Text = getdt.GetDocCountViewDownld(new Guid(ddlusers.SelectedValue), PrjUID, FromDate, ToDate, 1, "Viewed").ToString();
                            e.Row.Cells[5].Text=getdt.GetDocLinkSentCount(new Guid(ddlusers.SelectedValue), PrjUID, FromDate, ToDate, 1).ToString();
                        }
                        else
                        {
                            e.Row.Cells[2].Text = getdt.GetProjectdocumnetscountByPrj(new Guid(ddlusers.SelectedValue), PrjUID, FromDate, ToDate, 0).ToString();
                            e.Row.Cells[3].Text = getdt.GetDocCountViewDownld(new Guid(ddlusers.SelectedValue), PrjUID, FromDate, ToDate, 0, "Downloaded").ToString();
                            e.Row.Cells[4].Text = getdt.GetDocCountViewDownld(new Guid(ddlusers.SelectedValue), PrjUID, FromDate, ToDate, 0, "Viewed").ToString();
                            e.Row.Cells[5].Text = getdt.GetDocLinkSentCount(new Guid(ddlusers.SelectedValue), PrjUID, FromDate, ToDate, 0).ToString();
                        }

                        totalactcount += int.Parse(e.Row.Cells[2].Text);
                    }
                    totalcount += int.Parse(e.Row.Cells[2].Text);
                    grandtotalcount += int.Parse(e.Row.Cells[2].Text);
                    totaldwnldcount += int.Parse(e.Row.Cells[3].Text);
                    totalviewcount += int.Parse(e.Row.Cells[4].Text);
                    TotalDocumentLinkSentCount += int.Parse(e.Row.Cells[5].Text);
                }
                else if (e.Row.Cells[1].Text == "Total")
                {
                    e.Row.Cells[1].Font.Bold = true;
                    e.Row.Cells[2].Text = totalcount.ToString();
                    e.Row.Cells[3].Text = totaldwnldcount.ToString();
                    e.Row.Cells[4].Text = totalviewcount.ToString();
                    e.Row.Cells[5].Text = TotalDocumentLinkSentCount.ToString();
                }


                lblDocumentsNo.Text = "Total No. Of Documents : " + grandtotalcount + " : No of Activity Documents : " + totalactcount + " : No. Of General Documents : " + totalgdcount;


            }
        }

        protected void grdDocumenthistoryAll_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DateTime FromDate = DateTime.Now;
            DateTime ToDate = DateTime.Now;
            if (!string.IsNullOrEmpty(dtFromDate.Text))
            {
                FromDate = Convert.ToDateTime(getdt.ConvertDateFormat(dtFromDate.Text));
            }
            if (!string.IsNullOrEmpty(dtToDate.Text))
            {
                ToDate = Convert.ToDateTime(getdt.ConvertDateFormat(dtToDate.Text));
            }

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.Cells[2].Text != "&nbsp;") // if it is not total row
                {
                    Guid PrjUID = new Guid(e.Row.Cells[2].Text);
                    Guid UserUID = new Guid(e.Row.Cells[0].Text);
                    e.Row.Cells[0].Text = getdt.getUserNameby_UID(UserUID);
                    if (name != e.Row.Cells[0].Text)
                    {
                        totalcount = 0;
                        totalviewcount = 0;
                        totaldwnldcount = 0;
                        TotalDocumentLinkSentCount = 0;
                        name = e.Row.Cells[0].Text;
                    }
                    else
                    {
                        e.Row.Cells[0].Text = "";
                    }

                    if (e.Row.Cells[1].Text == "General Documents")
                    {
                        if (dtFromDate.Text != "" && dtToDate.Text != "")
                        {
                            e.Row.Cells[2].Text = getdt.GetGDByUsercount(UserUID, FromDate, ToDate, 1,"All").ToString();
                            e.Row.Cells[3].Text = getdt.GetDocCountViewDownldGD(UserUID, FromDate, ToDate, 1, "Downloaded").ToString();
                            e.Row.Cells[4].Text = getdt.GetDocCountViewDownldGD(UserUID, FromDate, ToDate, 1, "Viewed").ToString();
                            e.Row.Cells[5].Text = getdt.GetUserDocLinkSentCount_GD(UserUID, FromDate, ToDate, 1).ToString();

                        }
                        else
                        {
                            e.Row.Cells[2].Text = getdt.GetGDByUsercount(UserUID, FromDate, ToDate, 0, "All").ToString();
                            e.Row.Cells[3].Text = getdt.GetDocCountViewDownldGD(UserUID, FromDate, ToDate, 0, "Downloaded").ToString();
                            e.Row.Cells[4].Text = getdt.GetDocCountViewDownldGD(UserUID, FromDate, ToDate, 0, "Viewed").ToString();
                            e.Row.Cells[5].Text = getdt.GetUserDocLinkSentCount_GD(UserUID, FromDate, ToDate, 0).ToString();

                        }
                        totalgdcount += int.Parse(e.Row.Cells[2].Text);
                    }
                    else
                    {

                        if (dtFromDate.Text != "" && dtToDate.Text != "")
                        {
                            e.Row.Cells[2].Text = getdt.GetProjectdocumnetscountByPrj(UserUID, PrjUID, FromDate, ToDate, 1).ToString();
                            e.Row.Cells[3].Text = getdt.GetDocCountViewDownld(UserUID, PrjUID, FromDate, ToDate, 1, "Downloaded").ToString();
                            e.Row.Cells[4].Text = getdt.GetDocCountViewDownld(UserUID, PrjUID, FromDate, ToDate, 1, "Viewed").ToString();
                            e.Row.Cells[5].Text = getdt.GetDocLinkSentCount(UserUID, PrjUID, FromDate, ToDate, 1).ToString();
                        }
                        else
                        {
                            e.Row.Cells[2].Text = getdt.GetProjectdocumnetscountByPrj(UserUID, PrjUID, FromDate, ToDate, 0).ToString();
                            e.Row.Cells[3].Text = getdt.GetDocCountViewDownld(UserUID, PrjUID, FromDate, ToDate, 0, "Downloaded").ToString();
                            e.Row.Cells[4].Text = getdt.GetDocCountViewDownld(UserUID, PrjUID, FromDate, ToDate, 0, "Viewed").ToString();
                            e.Row.Cells[5].Text = getdt.GetDocLinkSentCount(UserUID, PrjUID, FromDate, ToDate, 0).ToString();
                        }
                        totalactcount += int.Parse(e.Row.Cells[2].Text);
                    }
                    totalcount += int.Parse(e.Row.Cells[2].Text);
                    grandtotalcount += int.Parse(e.Row.Cells[2].Text);
                    totaldwnldcount += int.Parse(e.Row.Cells[3].Text);
                    totalviewcount += int.Parse(e.Row.Cells[4].Text);
                    grandtotaldwnldcount += int.Parse(e.Row.Cells[3].Text);
                    grandtotalviewcount += int.Parse(e.Row.Cells[4].Text);
                    TotalDocumentLinkSentCount+= int.Parse(e.Row.Cells[5].Text);
                    GrandTotalDocumentLinkSent += int.Parse(e.Row.Cells[5].Text);
                }
                else
                {
                    e.Row.Cells[1].Font.Bold = true;
                    e.Row.Cells[2].Text = totalcount.ToString();
                    e.Row.Cells[3].Text = totaldwnldcount.ToString();
                    e.Row.Cells[4].Text = totalviewcount.ToString();
                    e.Row.Cells[5].Text = TotalDocumentLinkSentCount.ToString();
                }
                lblDocumentsNo.Text = "Total No. Of Documents : " + grandtotalcount + " : No of Activity Documents : " + totalactcount + " : No. Of General Documents : " + totalgdcount + " : Downloaded Documents : " + grandtotaldwnldcount + " : Viewed Documents : " + grandtotalviewcount + " : Document Link Sent : " + GrandTotalDocumentLinkSent;


            }
        }

        protected void GrdDocuments_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                HtmlGenericControl divD = (HtmlGenericControl)e.Row.FindControl("divD");
                HtmlGenericControl divGD = (HtmlGenericControl)e.Row.FindControl("divGD");
                DateTime FromDate = DateTime.Now;
                DateTime ToDate = DateTime.Now;
                if (!string.IsNullOrEmpty(dtFromDate.Text))
                {
                    FromDate = Convert.ToDateTime(getdt.ConvertDateFormat(dtFromDate.Text));
                }
                if (!string.IsNullOrEmpty(dtToDate.Text))
                {
                    ToDate = Convert.ToDateTime(getdt.ConvertDateFormat(dtToDate.Text));
                }
                if (e.Row.Cells[2].Text == "" || e.Row.Cells[2].Text == "&nbsp;") // if it is general document
                {
                    divD.Visible = false;
                    divGD.Visible = true;
                }
                if(!string.IsNullOrEmpty(e.Row.Cells[6].Text))
                {
                    if (e.Row.Cells[2].Text == "" || e.Row.Cells[2].Text == "&nbsp;") // if it is general document
                    {
                        if (dtFromDate.Text != "" && dtToDate.Text != "" && ddlusers.SelectedValue != "All Users")
                        {
                            e.Row.Cells[6].Text = getdt.GetDocCountViewDownldGDByDoc(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 1, "Downloaded", new Guid(e.Row.Cells[5].Text)).ToString();
                        }
                        else if (dtFromDate.Text == "" && dtToDate.Text == "" && ddlusers.SelectedValue != "All Users")
                        {
                            e.Row.Cells[6].Text = getdt.GetDocCountViewDownldGDByDoc(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 0, "Downloaded", new Guid(e.Row.Cells[6].Text)).ToString();
                        }
                        else if (dtFromDate.Text != "" && dtToDate.Text != "" && ddlusers.SelectedValue == "All Users")
                        {
                            e.Row.Cells[6].Text=getdt.GetDownloadDocumentCount_By_DocUID_For_GD(FromDate, ToDate, 1, "Downloaded", new Guid(e.Row.Cells[6].Text)).ToString();
                        }
                        else
                        {
                            e.Row.Cells[6].Text = getdt.GetDownloadDocumentCount_By_DocUID_For_GD(FromDate, ToDate, 0, "Downloaded", new Guid(e.Row.Cells[6].Text)).ToString();
                        }
                    }
                    else
                    {
                        if (dtFromDate.Text != "" && dtToDate.Text != "" && ddlusers.SelectedValue != "All Users")
                        {
                            e.Row.Cells[6].Text = getdt.GetDocCountViewDownldByDoc(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 1, "Downloaded", new Guid(e.Row.Cells[6].Text)).ToString();
                        }
                        else if (dtFromDate.Text == "" && dtToDate.Text == "" && ddlusers.SelectedValue != "All Users")
                        {
                            e.Row.Cells[6].Text = getdt.GetDocCountViewDownldByDoc(new Guid(ddlusers.SelectedValue), FromDate, ToDate, 0, "Downloaded", new Guid(e.Row.Cells[6].Text)).ToString();
                        }
                        else if (dtFromDate.Text != "" && dtToDate.Text != "" && ddlusers.SelectedValue == "All Users")
                        {
                            e.Row.Cells[6].Text = getdt.GetDownloadDocumentCount_by_DocumentUID(FromDate, ToDate, 1, "Downloaded", new Guid(e.Row.Cells[6].Text)).ToString();
                        }
                        else
                        {
                            e.Row.Cells[6].Text = getdt.GetDownloadDocumentCount_by_DocumentUID(FromDate, ToDate, 0, "Downloaded", new Guid(e.Row.Cells[6].Text)).ToString();
                        }
                    }
                }
                string DocumentUID = GrdDocuments.DataKeys[e.Row.RowIndex].Values[0].ToString();

                DataSet ds = getdt.GetDocumentSent_by_DocumentUID(new Guid(DocumentUID));
                if (ds.Tables[0].Rows.Count <= 0)
                {
                    //Label lblcnt = (Label)e.Row.FindControl("LblCount");
                    //lblcnt.Text = "0";
                    //lblcnt.Enabled = false;
                    e.Row.Cells[7].Text = "0";
                    e.Row.Cells[7].Enabled = false;
                }
                else
                {
                    Label lblcnt = (Label)e.Row.FindControl("LblCount");
                    lblcnt.Text = ds.Tables[0].Rows.Count.ToString();
                    e.Row.Cells[7].Enabled = true;
                    lblcnt.Enabled = true;
                }
            }
        }

        protected void ddlProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadUsers();
        }

        protected void ddlOptions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlOptions.SelectedValue == "2")
            {
                DivStatus.Visible = true;
                DivFilter.Visible = true;
            }
            else
            {
                DivStatus.Visible = false;
                DivFilter.Visible = false;
            }
        }

        public string GetUserName(string UserUID)
        {
            return getdt.getUserNameby_UID(new Guid(UserUID));
        }
    }
}